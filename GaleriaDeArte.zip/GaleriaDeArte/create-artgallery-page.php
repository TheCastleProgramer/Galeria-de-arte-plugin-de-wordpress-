<?php
/*
Plugin Name: ArtGallery Page
Description: Un plugin para crear una galeria de arte
Version: 1.0
Author: TheCastleProgramer
*/

function create_artgallery_page() {
    $page_title = 'ArtGallery';
    $page_content = '[artgallery_products_grid]';
    $page_check = get_page_by_title($page_title);

    if (!isset($page_check->ID)) {
        $new_page = array(
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page'
        );

        wp_insert_post($new_page);
    }
}

register_activation_hook(__FILE__, 'create_artgallery_page');

function artgallery_settings_menu() {
    add_menu_page(
        'ArtGallery Settings',   // Título de la página
        'ArtGallery Settings',   // Título del menú
        'manage_options',        // Capacidad requerida
        'artgallery-settings',   // Slug del menú
        'artgallery_settings_page', // Función que muestra el contenido de la página
        'dashicons-admin-generic', // Icono del menú
        20                       // Posición del menú
    );

    add_submenu_page(
        'artgallery-settings',
        'Add Product',
        'Add Product',
        'manage_options',
        'artgallery-add-product',
        'artgallery_add_product_page'
    );

    add_submenu_page(
        'artgallery-settings',
        'Product List',
        'Product List',
        'manage_options',
        'artgallery-product-list',
        'artgallery_product_list_page'
    );

    add_submenu_page(
        'artgallery-settings',
        'Settings',
        'Settings',
        'manage_options',
        'artgallery-settings-page',
        'artgallery_settings_subpage'
    );
}
add_action('admin_menu', 'artgallery_settings_menu');

function artgallery_settings_page() {
    ?>
    <div class="wrap">
        <h1>ArtGallery Settings</h1>
        <p>Welcome to the ArtGallery plugin settings. Use the submenus to manage your products and settings.</p>
    </div>
    <?php
}

function artgallery_add_product_page() {
    ?>
    <div class="wrap">
        <h1>Add New Product</h1>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="add_artgallery_product">
            <?php wp_nonce_field('artgallery_add_product_verify', 'artgallery_nonce'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Product Name</th>
                    <td><input type="text" name="product_name" required /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Description</th>
                    <td><textarea name="product_description" required></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Product Image</th>
                    <td>
                        <input type="hidden" name="product_image" id="product_image" />
                        <button type="button" class="button" id="upload_image_button">Select Image</button>
                        <div id="image_preview"></div>
                    </td>
                </tr>
            </table>
            <?php submit_button('Add Product'); ?>
        </form>
    </div>
    <?php
}

function artgallery_product_list_page() {
    $products = get_option('artgallery_products', []);
    ?>
    <div class="wrap">
        <h1>Product List</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
            <tr>
                <th scope="col" class="manage-column">Product Name</th>
                <th scope="col" class="manage-column">Description</th>
                <th scope="col" class="manage-column">Image</th>
                <th scope="col" class="manage-column">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php if (!empty($products)) : ?>
                <?php foreach ($products as $index => $product) : ?>
                    <tr>
                        <td><?php echo esc_html($product['name']); ?></td>
                        <td><?php echo esc_html($product['description']); ?></td>
                        <td><img src="<?php echo esc_url($product['image_url']); ?>" style="max-width: 100px;" /></td>
                        <td>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                <input type="hidden" name="action" value="delete_artgallery_product">
                                <input type="hidden" name="product_index" value="<?php echo esc_attr($index); ?>">
                                <?php wp_nonce_field('artgallery_delete_product_verify', 'artgallery_delete_nonce'); ?>
                                <input type="submit" class="button button-danger" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="4">No products found.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

function artgallery_settings_subpage() {
    ?>
    <div class="wrap">
        <h1>ArtGallery Plugin Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('artgallery_settings_group');
            do_settings_sections('artgallery-settings-page');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function artgallery_save_product() {
    if (!isset($_POST['artgallery_nonce']) || !wp_verify_nonce($_POST['artgallery_nonce'], 'artgallery_add_product_verify')) {
        wp_die('Nonce verification failed.');
    }

    if (isset($_POST['product_name']) && isset($_POST['product_description']) && isset($_POST['product_image'])) {
        $product_name = sanitize_text_field($_POST['product_name']);
        $product_description = sanitize_textarea_field($_POST['product_description']);
        $product_image_url = esc_url_raw($_POST['product_image']);

        $products = get_option('artgallery_products', []);
        $products[] = [
            'name' => $product_name,
            'description' => $product_description,
            'image_url' => $product_image_url
        ];
        update_option('artgallery_products', $products);

        wp_redirect(admin_url('admin.php?page=artgallery-product-list'));
        exit;
    }
}
add_action('admin_post_add_artgallery_product', 'artgallery_save_product');

function artgallery_delete_product() {
    if (!isset($_POST['artgallery_delete_nonce']) || !wp_verify_nonce($_POST['artgallery_delete_nonce'], 'artgallery_delete_product_verify')) {
        wp_die('Nonce verification failed.');
    }

    if (isset($_POST['product_index'])) {
        $product_index = intval($_POST['product_index']);
        $products = get_option('artgallery_products', []);

        if (isset($products[$product_index])) {
            unset($products[$product_index]);
            $products = array_values($products); // Reindex array
            update_option('artgallery_products', $products);
        }

        wp_redirect(admin_url('admin.php?page=artgallery-product-list'));
        exit;
    }
}
add_action('admin_post_delete_artgallery_product', 'artgallery_delete_product');

function artgallery_enqueue_media() {
    wp_enqueue_media();
    wp_enqueue_script('artgallery-admin-script', plugin_dir_url(__FILE__) . 'artgallery-admin.js', ['jquery'], null, true);
}
add_action('admin_enqueue_scripts', 'artgallery_enqueue_media');

function artgallery_register_settings() {
    register_setting('artgallery_settings_group', 'artgallery_option');
    register_setting('artgallery_settings_group', 'artgallery_grid_columns');
    register_setting('artgallery_settings_group', 'artgallery_grid_item_width');
    register_setting('artgallery_settings_group', 'artgallery_grid_item_height');

    add_settings_section('artgallery_settings_section', 'General Settings', 'artgallery_settings_section_callback', 'artgallery-settings-page');

    add_settings_field('artgallery_option_field', 'Sample Option', 'artgallery_option_field_callback', 'artgallery-settings-page', 'artgallery_settings_section');
    add_settings_field('artgallery_grid_columns', 'Grid Columns', 'artgallery_grid_columns_callback', 'artgallery-settings-page', 'artgallery_settings_section');
    add_settings_field('artgallery_grid_item_width', 'Grid Item Width (px)', 'artgallery_grid_item_width_callback', 'artgallery-settings-page', 'artgallery_settings_section');
    add_settings_field('artgallery_grid_item_height', 'Grid Item Height (px)', 'artgallery_grid_item_height_callback', 'artgallery-settings-page', 'artgallery_settings_section');
}
add_action('admin_init', 'artgallery_register_settings');

function artgallery_settings_section_callback() {
    echo 'Adjust the settings for the ArtGallery plugin below.';
}

function artgallery_option_field_callback() {
    $option = get_option('artgallery_option');
    echo '<input type="text" name="artgallery_option" value="' . esc_attr($option) . '" />';
}

function artgallery_grid_columns_callback() {
    $columns = get_option('artgallery_grid_columns', 3);
    echo '<input type="number" name="artgallery_grid_columns" value="' . esc_attr($columns) . '" min="1" />';
}

function artgallery_grid_item_width_callback() {
    $width = get_option('artgallery_grid_item_width', 200);
    echo '<input type="number" name="artgallery_grid_item_width" value="' . esc_attr($width) . '" min="50" />';
}

function artgallery_grid_item_height_callback() {
    $height = get_option('artgallery_grid_item_height', 300);
    echo '<input type="number" name="artgallery_grid_item_height" value="' . esc_attr($height) . '" min="50" />';
}

function artgallery_products_grid_shortcode() {
    $products = get_option('artgallery_products', []);
    $columns = get_option('artgallery_grid_columns', 3);
    $item_width = get_option('artgallery_grid_item_width', 200);
    $item_height = get_option('artgallery_grid_item_height', 300);

    ob_start();
    echo '<div class="artgallery-grid" style="display: grid; grid-template-columns: repeat(' . intval($columns) . ', 1fr); gap: 10px; margin: 20px 0;">';
    foreach ($products as $product) {
        echo '<div class="artgallery-item" style="width: ' . intval($item_width) . 'px; height: ' . intval($item_height) . 'px; padding: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">';
        echo '<img src="' . esc_url($product['image_url']) . '" alt="' . esc_attr($product['name']) . '" style="width: 100%; height: auto; margin-bottom: 10px;">';
        echo '<h2 style="font-size: 1.2em; margin: 0 0 10px;">' . esc_html($product['name']) . '</h2>';
        echo '<p style="font-size: 0.9em;">' . esc_html($product['description']) . '</p>';
        echo '</div>';
    }
    echo '</div>';
    return ob_get_clean();
}
add_shortcode('artgallery_products_grid', 'artgallery_products_grid_shortcode');

function artgallery_grid_styles() {
    ?>
    <style>
        .artgallery-grid {
            display: grid;
            gap: 10px;
            margin: 20px 0;
        }
        .artgallery-item {
            padding: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .artgallery-item img {
            width: 100%;
            height: auto;
            margin-bottom: 10px;
        }
        .artgallery-item h2 {
            font-size: 1.2em;
            margin: 0 0 10px;
            text-align: center;
        }
        .artgallery-item p {
            font-size: 0.9em;
            text-align: center;
        }
    </style>
    <?php
}
add_action('wp_head', 'artgallery_grid_styles');
?>